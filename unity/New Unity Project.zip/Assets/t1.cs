using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class t1 : MonoBehaviour
{
    public GameObject t_obj;
    public int t_flag = 0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    void OnMouseDown()
    {
        t_obj = gameObject;
        if(t_flag == 0)
        {
            t_obj.transform.GetChild(0).transform.Translate(0, 70, 0);
            t_obj.transform.GetChild(1).transform.Translate(0, 40, 0);
            t_flag = 1;
        }
        else
        {
            t_obj.transform.GetChild(0).transform.Translate(0, -70, 0);
            t_obj.transform.GetChild(1).transform.Translate(0, -40, 0);
            t_flag = 0;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
