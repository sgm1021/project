using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class dds : MonoBehaviour
{
    static public string pName;
    public Dropdown dropdown;
    List<string> names = new List<string>();
    public Button bnt1;
    public GameObject prefabGameObject1;
    public GameObject prefabGameObject2;
    public GameObject obj1 = null;
    public GameObject obj2 = null;
    /*public void DropdownIndexChanged(int index)
    {
        dds.selectedName = names[index];
    }*/

    // Start is called before the first frame update
    void Start()
    {
        dropdown.options.Clear();
        PopulateList();
        //bnt1.onClick.AddListener(addObj)

    }

    void PopulateList()
    {
        
        for(int i=0; i<5; i++)
        {
            names.Add("ȯ�� " + i.ToString());
        }
        dropdown.AddOptions(names);
        
    }

    public void click111()
    {
        Debug.Log("asdf");
        //Color color = new Color(Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f));
        Color color = new Color(Random.value, Random.value, Random.value);
        if(obj1 == null && obj2 == null)
        {
            prefabGameObject1 = Resources.Load<GameObject>("Prefabs/down");
            obj1 = Instantiate(prefabGameObject1);
            prefabGameObject2 = (GameObject)Resources.Load("Prefabs/up");
            obj2 = Instantiate(prefabGameObject2) as GameObject;
        }
        else
        {
            Destroy(obj1);
            Destroy(obj2);
            prefabGameObject1 = Resources.Load<GameObject>("Prefabs/down");
            obj1 = Instantiate(prefabGameObject1);
            prefabGameObject2 = (GameObject)Resources.Load("Prefabs/up");
            obj2 = Instantiate(prefabGameObject2) as GameObject;
        }
        
        obj1.GetComponent<MeshRenderer>().material.color = color;
        obj2.GetComponent<MeshRenderer>().material.color = color;

    }

    /*void addObj()
    {
        Debug.Log("asdf");
        //Color color = new Color(Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f));
        //Color color = new Color(Random.value, Random.value, Random.value);
        GameObject prefabGameObject1 = Resources.Load<GameObject>("Prefabs/down");
        GameObject obj1 = Instantiate(prefabGameObject1);
        //GameObject prefabGameObject2 = (GameObject)Resources.Load("Prefabs/up");
        //GameObject obj2 = Instantiate(prefabGameObject2) as GameObject;
        //obj1.GetComponent<MeshRenderer>().material.color = color;
        //obj2.GetComponent<MeshRenderer>().material.color = color;
    }*/

    // Update is called once per frame
    void Update()
    {
        bnt1.transform.GetChild(0).GetComponent<Text>().text = names[dropdown.value] + " Ȯ��";
    }
}
