using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cv : MonoBehaviour
{
    static public GameObject cv1;
    // Start is called before the first frame update
    void Start()
    {
        cv.cv1 = gameObject;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
