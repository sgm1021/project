using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class desk : MonoBehaviour
{
    static public GameObject d_obj;
    static public int seat=0;
    public int cIndex = 0;
    public int m_flag = 0;
    public Vector3 move_obj_1, move_obj_2;
    public Vector3 seat_pos;
    public float speed = 1.0f;
    static public Dictionary<GameObject, int> s_dic = new Dictionary<GameObject, int>();
    // Start is called before the first frame update
    void Start()
    {
        
    }

    void OnMouseDown()
    {
        student2.s_obj.transform.rotation = Quaternion.Euler(0, 0, 0);
        student2.s_obj.transform.Translate(20, -20, 0);
        if (student2.s_flag == 1)
        {
            m_flag = 1;
            student2.s_flag = 0;
            desk.d_obj = gameObject;
            desk.s_dic.Add(student2.s_obj, seat);
            seat_pos = new Vector3(desk.d_obj.transform.position.x + 20, student2.s_obj.transform.position.y, desk.d_obj.transform.position.z);
            if (seat == 0)
            {
                seat_pos.z = seat_pos.z - 10;
                move_obj_1 = new Vector3(student2.s_obj.transform.position.x, seat_pos.y, seat_pos.z-20);
                move_obj_2 = new Vector3(seat_pos.x, move_obj_1.y, move_obj_1.z);
                
                desk.seat = 1;
            }
            else
            {
                seat_pos.z = seat_pos.z + 10;
                move_obj_1 = new Vector3(student2.s_obj.transform.position.x, seat_pos.y, seat_pos.z + 20);
                move_obj_2 = new Vector3(seat_pos.x, move_obj_1.y, move_obj_1.z);
                
                desk.seat = 0;
            }


            if (bus1.objs.Contains(student2.s_obj))
            {
                cIndex = bus1.objs.IndexOf(student2.s_obj);
                bus1.objs.RemoveAt(bus1.objs.IndexOf(student2.s_obj));
            }
            
            for (int i = cIndex; i < bus1.objs.Count; i++)
            {
                //bus1.objs[i].transform.position = new Vector3(150, 10, 0);
                //bus1.objs[i].transform.position = this.transform.position;
                if (bus1.objs[i].transform.position.x < -100)
                {
                    bus1.objs[i].transform.Translate(0, 0, 15);
                }
                
            }    
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (m_flag == 1)
        {
            student2.s_obj.transform.position = Vector3.MoveTowards(student2.s_obj.transform.position, move_obj_1, 0.3f);
            student2.s_obj.transform.LookAt(move_obj_1);
            if (student2.s_obj.transform.position == move_obj_1)
            {
                m_flag = 2;
            }
        }
        else if (m_flag == 2)
        {
            student2.s_obj.transform.position = Vector3.MoveTowards(student2.s_obj.transform.position, move_obj_2, 0.3f);
            student2.s_obj.transform.LookAt(move_obj_2);
            if (student2.s_obj.transform.position == move_obj_2)
            {
                m_flag = 3;
            }
        }
        else if (m_flag == 3)
        {
            student2.s_obj.transform.position = Vector3.MoveTowards(student2.s_obj.transform.position, seat_pos, 0.3f);
            student2.s_obj.transform.LookAt(seat_pos);
            if (student2.s_obj.transform.position == seat_pos)
            {
                m_flag = 0;
                student2.s_obj.transform.rotation = Quaternion.Euler(0, -90, 0);
            }
        }
    }
}
