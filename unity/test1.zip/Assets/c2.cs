using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cb2
{
    static public Vector3 mv2 = new Vector3(0, 0, 0);
    public Vector3 getv2() { return Cb2.mv2; }
}
public class c2 : MonoBehaviour
{
    
    void Awake(){
        Debug.Log("Awake script2");
    }
    // Start is called before the first frame update
    void Start()
    {
        // transform.Translate(68, 2, 10);
    }

    void go_left(float a)
    {
        transform.position+=new Vector3(0, 0, -a);
    }
    void go_right(float a)
    {
        transform.position+=new Vector3(0, 0, a);
    }
    void go_up(float a)
    {
        transform.position+=new Vector3(-a, 0, 0);
    }
    void go_down(float a)
    {
        transform.position+=new Vector3(a, 0, 0);
    }
    public float t = 0;
    // Update is called once per frame
    void Update()
    {   
        t+=0.3f;
        if(t < 65.0f){
            go_left(0.3f);
        }
        else if(t<95.0f){
            go_down(0.3f);
        }
        else if(t<135.0f){
            go_right(0.3f);
        }
        else if(t<173.0f){
            go_down(0.3f);
        }
        else if(t<203.0f){
            go_left(0.3f);
        }
        Cb2.mv2 = transform.position;
    }
}
