using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class desks : MonoBehaviour
{

    public GameObject prefabGameObject;
    public GameObject obj;
    // Start is called before the first frame update
    void Start()
    {
        prefabGameObject = (GameObject)Resources.Load("Prefabs/desk");
        for(int i = 0; i < 2; i++)
        {
            for (int j = 0; j<5; j++)
            {
                obj = Instantiate(prefabGameObject);// ������Ʈ ����
                if (i > 0)
                {
                    obj.transform.position = new Vector3(j * 40 - 80, 10, 40);
                }
                else
                {
                    obj.transform.position = new Vector3(j * 40 - 80, 10, -40);
                }
                //obj.transform.parent = gameObject.transform; // �θ������Ʈ�� �ֱ�
            }
            

        }
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
