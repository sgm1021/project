using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dt1 : MonoBehaviour
{
    public TextMesh mTm;
    public Vector3 p1, p2;
    static public bool mc1 = true;
    // Start is called before the first frame update
    

    void Start()
    {
        mTm = GetComponent<TextMesh>();
    }
    // Update is called once per frame
    void Update()
    {
        p1 = transform.position;
        
        // Cb b2 = new Cb();
        // mTm.text = b2.getv().ToString();
        Cb1 b1 = new Cb1();
        p2 = b1.getv1();
        // mTm.text = b1.getv1().ToString();
        transform.position = new Vector3(b1.getv1().x, b1.getv1().y, b1.getv1().z);
        if(p1 == p2){
            mTm.text = "완료";
            dt1.mc1 = true;
        }
        else{
            mTm.text = "이동중";
            dt1.mc1 = false;
        }
        
    }
}

