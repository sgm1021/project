using System.Collections;
using System.Collections.Generic;
using System;
using System.Linq;
using System.Text;
using UnityEngine;

public class Client : JcCtUnity1.JcCtUnity1
{
	static public Client gThis = new Client();
	public Client() : base(Encoding.Unicode) { }
	public void qv(string s1) { innLogOutput(s1); }

	// JcCtUnity1.JcCtUnity1
	protected override void innLogOutput(string s1) { Debug.Log(s1); }
	protected override void onConnect(JcCtUnity1.NwRst1 rst1, System.Exception ex = null)
	{
		qv("Dbg on connect: " + rst1);
		int pkt = 1111;
		using (JcCtUnity1.PkWriter1Nm pkw = new JcCtUnity1.PkWriter1Nm(pkt))
		{
			pkw.wInt32u((UInt32)2222);
			this.send(pkw);
		}
		qv("Dbg send packet Type:" + pkt);
	}
	protected override void onDisconnect()
	{ qv("Dbg on disconnect"); }
	protected override bool onRecvTake(Jc1Dn2_0.PkReader1 pkrd)
	{ qv("Dbg on recv: " + pkrd.getPkt()/* + pkrd.ReadString()*/ ); return true; }
}
public class clientGO_script : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
		if (!Client.gThis.connect("127.0.0.1", 7777))
		{
			Debug.Log("Dbg connect fail"); return;
		}
    }

    // Update is called once per frame
    void Update()
    {
		Client.gThis.framemove();
    }
}
