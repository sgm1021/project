using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class student2 : MonoBehaviour
{
    // public int cIndex = 0;
    // Start is called before the first frame update
    static public int s_flag = 0;
    static public GameObject s_obj;
    public Vector3 move_obj_1, move_obj_2;
    public Vector3 r_pos;
    public int m_flag = 0;
    void Start()
    {
        
    }
    void OnMouseDown()
    {
        
        if (bus1.objs.Contains(gameObject))
        {
            if (s_flag == 0)
            {
                student2.s_flag = 1;
                this.transform.Translate(0, 20, 0);
                student2.s_obj = gameObject;
            }
            else if (s_flag == 1 && s_obj == gameObject)
            {
                student2.s_flag = 0;
                student2.s_obj = null;
                this.transform.Translate(0, -20, 0);
            }
            else if (s_flag == 1 && s_obj != gameObject)
            {
                student2.s_obj.transform.Translate(0, -20, 0);
                student2.s_obj = gameObject;
                this.transform.Translate(0, 20, 0);
            }
        }
        else
        {
            r_pos = bus1.objs[bus1.objs.Count - 1].transform.position;
            r_pos.z += 15;
            //gameObject.transform.position = r_pos;
            bus1.objs.Add(gameObject);

            
            if(desk.s_dic[gameObject] == 0)
            {
                move_obj_1 = gameObject.transform.position;
                move_obj_1.z -= 30;
                move_obj_2 = move_obj_1;
                move_obj_2.x = -100;
                desk.s_dic.Remove(gameObject);
            }
            else if (desk.s_dic[gameObject] == 1)
            {
                move_obj_1 = gameObject.transform.position;
                move_obj_1.z += 30;
                move_obj_2 = move_obj_1;
                move_obj_2.x = -100;
                desk.s_dic.Remove(gameObject);
            }
            
            m_flag = 1;
        }


        
    }
    // Update is called once per frame
    void Update()
    {
        if (m_flag == 1)
        {
            gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, move_obj_1, 0.3f);
            gameObject.transform.LookAt(move_obj_1);
            if (gameObject.transform.position == move_obj_1)
            {
                m_flag = 2;
            }
        }
        else if (m_flag == 2)
        {
            gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, move_obj_2, 0.3f);
            gameObject.transform.LookAt(move_obj_2);
            if (gameObject.transform.position == move_obj_2)
            {
                m_flag = 3;
            }
        }
        else if (m_flag == 3)
        {
            gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, r_pos, 0.3f);
            gameObject.transform.LookAt(r_pos);
            if (gameObject.transform.position == r_pos)
            {
                m_flag = 0;
                gameObject.transform.rotation = Quaternion.Euler(0, 180, 0);
            }
        }
    }
}
