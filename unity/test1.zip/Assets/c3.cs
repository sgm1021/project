using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// public class Cb
// {
//     // static public float mx = 0;
//     // public float getx(){return Cb.mx;}
//     // static public Vector3 mv = new Vector3(0, 0, 0);
//     public Vector3 getv(){return Cb.mv;}
//     // static public string gText = "None";
//     // public string gett(){return Cb.gText;}
// }

public class Cb3 
{
    static public Vector3 mv3 = new Vector3(0, 0, 0);
    public Vector3 getv3() { return Cb3.mv3;}
}


public class c3 : MonoBehaviour
{
    public Material mMaterial;
    
    void Awake(){
        // Cb b1 = new Cb();
        // Debug.Log(b1.getx()+ ", " + b1.gety()+ ", " + b1.getz());
    }

    void OnMouseDown(){
        Debug.Log("OnMouseDown");
        mMaterial.color = Color.red;
    }

    void OnMouseUp(){
        Debug.Log("OnMouseUp");
    }

    void OnDestroy()
    {
        Destroy(mMaterial);
    }
    // Start is called before the first frame update
    void Start()
    {
        // transform.Translate(98, 2, -80);
        mMaterial = GetComponent<Renderer>().material;
    }

    void go_left(float a)
    {
        transform.position+=new Vector3(0, 0, -a);
    }
    void go_right(float a)
    {
        transform.position+=new Vector3(0, 0, a);
    }
    void go_up(float a)
    {
        transform.position+=new Vector3(-a, 0, 0);
    }
    void go_down(float a)
    {
        transform.position+=new Vector3(a, 0, 0);
    }
    public float t = 0;
    // Update is called once per frame
    void Update()
    {   
        t+=0.3f;
        if(t < 88.0f){
            go_left(0.3f);
        }
        else if(t<115.0f){
            go_down(0.3f);
        }
        else if(t<158.0f){
            go_right(0.3f);
        }
        else if(t<229.0f){
            go_down(0.3f);
        }
        else if(t<250.0f){
            go_left(0.3f);
        }
        // Cb.mx = transform.position.x;
        Cb3.mv3 = transform.position;
        // Cb.gText = transform.position.ToString();
    }

}
