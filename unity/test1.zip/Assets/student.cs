using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class student : MonoBehaviour
{
    public GameObject prefabGameObject;
    public GameObject obj;
    static public List<GameObject> names = new List<GameObject>();
    // Start is called before the first frame update
    void Start()
    {
        prefabGameObject = (GameObject)Resources.Load("Prefabs/studentName");
        obj = Instantiate(prefabGameObject) as GameObject;
        obj.transform.position = this.transform.position;
        obj.transform.Translate(0, 15, 0);
        obj.GetComponent<TextMesh>().text = "student" + bus1.cnt;
        student.names.Add(obj);
    }

    void OnMouseDown()
    {
        Destroy(gameObject);
        Destroy(obj);
        student.names.RemoveAt(student.names.IndexOf(obj));
        for (int j = 0; j < student.names.Count; j++)
        {
            student.names[j].transform.position = new Vector3(180, 20, 0);
            student.names[j].transform.Translate(0, 0, j * 15);
        }
        bus1.objs.RemoveAt(bus1.objs.IndexOf(gameObject));
        for(int i = 0; i < bus1.objs.Count; i++)
        {
            bus1.objs[i].transform.position = new Vector3(180, 5, 0);
            bus1.objs[i].transform.Translate(0, 0, i*15);
        }

    }
    void OnMouseUp()
    {
        

    }

    // Update is called once per frame
    void Update()
    {
 
    }
}
