using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bus1 : MonoBehaviour
{
    static public List<GameObject> objs = new List<GameObject>();
    static public float cnt = 0;
    public int maxCnt = 10;

    // Start is called before the first frame update
    void Start()
    {
        
    }
    void OnMouseDown()
    {
        //Color color = new Color(Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f));
        Color color = new Color(Random.value, Random.value, Random.value);
        Debug.Log(color);
        if (maxCnt - bus1.objs.Count > 0)
        {
            cnt++;
            GameObject prefabGameObject = (GameObject)Resources.Load("Prefabs/Capsule");
            GameObject obj = Instantiate(prefabGameObject) as GameObject;
            obj.transform.Translate(0, 0, bus1.objs.Count * 15);
            obj.transform.GetChild(0).GetComponent<TextMesh>().text = "student " + cnt.ToString();
            obj.transform.rotation = Quaternion.Euler(0, 180, 0);
            obj.GetComponent<MeshRenderer>().material.color = color;
            obj.transform.GetChild(0).GetComponent<MeshRenderer>().material.color = color;
            obj.transform.GetChild(1).GetComponent<MeshRenderer>().material.color = color;
            obj.transform.GetChild(10).GetComponent<MeshRenderer>().material.color = color;
            objs.Add(obj);
        }
        
    }

    private void OnMouseDrag()
    {
        //transform.rotation = Quaternion.Euler(0, 50, 0);
        transform.Rotate(new Vector3(0, 50, 0));
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
