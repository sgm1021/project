using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dt4 : MonoBehaviour
{   
    public TextMesh mTm;
    // Start is called before the first frame update
    void Start()
    {
        mTm = GetComponent<TextMesh>();
    }

    // Update is called once per frame
    void Update()
    {
        if(dt1.mc1 == true && dt2.mc2 == true && dt3.mc3 == true){
            mTm.text = "완료";
        }
        else{
            mTm.text = "이동중";
        }
        
    }
}
